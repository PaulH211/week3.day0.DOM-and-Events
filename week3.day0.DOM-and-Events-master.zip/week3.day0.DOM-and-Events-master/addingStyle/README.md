# To Do List
1. Do NOT use CSS or alter the original HTML
2. In the "main.js" file, use the DOM to change the `.right_side` background color to #d3c26f
3. To the names, add a yellow text-shadow with horizontal shadow of -6px, vertical shadow of 5px, and a blur-radius of 2px
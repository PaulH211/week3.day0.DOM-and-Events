# To Do List
1. Do NOT use CSS or alter the original HTML
2. In the "main.js" file, use the DOM to change the `h1` name of the item to "Frostfang"
3. Also, change the image to "Frostfang_item.png" found in the "assets" folder
   - *Hint: you'll want to change the `src` of the `img` element*
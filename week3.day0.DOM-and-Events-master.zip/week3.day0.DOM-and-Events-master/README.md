# week3.day0.DOM-and-Events

## Instructions
1. Fork and clone this repo: [week3.day0.DOM-and-Events](https://github.com/AllStarCodeOrg/week3.day0.DOM-and-Events)
2. Follow the challenge found in the “README.md” of each folder

## Helpful Resources
- [W3Schools on JavaScript DOM methods](https://www.w3schools.com/js/js_htmldom_methods.asp)

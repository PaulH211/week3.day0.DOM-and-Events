# To Do List
1. Do NOT use CSS or alter the original HTML
2. Add an on click listener to the `document` that sets the `src` of the `#rengar` img element to "assets/rengar.png"
3. Include an `alert()` to tell the user "You've been deleted!"